# ESP32 DevKit1 — Backend de Autenticação e Monitoramento

Backend em **FastAPI** para o ESP32 DevKit1, com:

- 🔐 Autenticação do dashboard via **JWT**
- 📡 Recebimento de leituras dos dispositivos em **tempo real** (WebSocket)
- 🖥️ Dashboard web simples que mostra os dados ao vivo
- ⚡ Sem banco de dados — tudo em memória (dados são perdidos ao reiniciar o servidor)
- 🔑 Autenticação separada para dispositivos ESP32 via API Key

## Estrutura

```
esp32-backend/
├── app/
│   ├── main.py               # Rotas HTTP e WebSocket
│   ├── auth.py                # Login, JWT, hash de senha
│   ├── websocket_manager.py   # Conexões e estado em tempo real
│   └── config.py              # Configurações via .env
├── static/
│   └── dashboard.html         # Dashboard (HTML puro + JS)
├── firmware/
│   └── esp32_client.ino       # Exemplo de firmware pro ESP32 DevKit1
├── scripts/
│   └── generate_password_hash.py
├── requirements.txt
└── .env.example
```

## Como rodar

1. Crie o ambiente virtual e instale as dependências:

   ```bash
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. Copie o `.env.example` para `.env` e gere o hash da senha do admin:

   ```bash
   cp .env.example .env
   python scripts/generate_password_hash.py
   ```

   Cole o hash gerado na linha `ADMIN_PASSWORD_HASH` do `.env`, e defina uma
   `DEVICE_API_KEY` e `SECRET_KEY` fortes.

3. Suba o servidor:

   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```

4. Acesse `http://localhost:8000` no navegador e faça login com o usuário/senha
   configurados.

## Conectando o ESP32 DevKit1

Abra `firmware/esp32_client.ino` na Arduino IDE, ajuste:

- `WIFI_SSID` / `WIFI_PASSWORD`
- `SERVER_HOST` (IP da máquina rodando o backend na sua rede)
- `DEVICE_API_KEY` (mesma chave do `.env`)

Instale as bibliotecas `WebSockets` (Markus Sattler) e `ArduinoJson` pelo
Library Manager, e grave o firmware. O ESP32 vai se conectar e começar a
enviar leituras simuladas de temperatura/umidade a cada 5 segundos — troque
pela leitura real do seu sensor.

## Endpoints principais

| Método | Rota                          | Descrição                                  |
|--------|-------------------------------|---------------------------------------------|
| POST   | `/api/login`                  | Login do dashboard, retorna JWT              |
| GET    | `/api/devices`                | Lista dispositivos e últimas leituras (JWT)  |
| POST   | `/api/devices/{id}/command`   | Envia comando pro ESP32 (JWT)                |
| WS     | `/ws/device`                  | ESP32 conecta e envia leituras (API Key)     |
| WS     | `/ws/dashboard`               | Dashboard recebe dados em tempo real (JWT)   |

## Segurança

- Nunca commite o `.env` (já está no `.gitignore`).
- Troque `SECRET_KEY` e `DEVICE_API_KEY` por valores aleatórios fortes em produção.
- Em produção, sirva por HTTPS/WSS (ex: atrás de um Nginx com certificado TLS).

## Roadmap sugerido

- [ ] Persistência opcional (SQLite) para histórico de leituras
- [ ] Suporte a múltiplos usuários no dashboard
- [ ] Alertas (ex: notificação quando temperatura passa de X)

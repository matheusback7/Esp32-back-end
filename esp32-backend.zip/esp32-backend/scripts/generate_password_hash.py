"""
Gera o hash da senha do admin para colocar em ADMIN_PASSWORD_HASH no .env.

Uso:
    python scripts/generate_password_hash.py
"""
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.auth import hash_password  # noqa: E402

if __name__ == "__main__":
    pwd = getpass.getpass("Digite a senha do admin: ")
    pwd2 = getpass.getpass("Confirme a senha: ")
    if pwd != pwd2:
        print("As senhas não conferem.")
        sys.exit(1)
    print("\nAdicione esta linha ao seu arquivo .env:\n")
    print(f"ADMIN_PASSWORD_HASH={hash_password(pwd)}")
